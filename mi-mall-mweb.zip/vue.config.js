module.exports = {
  chainWebpack: config => {
    const oneOfsMap = config.module.rule('scss').oneOfs.store

    oneOfsMap.forEach(item => {
      item
        .use('sass-resources-loader')
        .loader('sass-resources-loader')
        .options({
          // 把全局公用的样式，全局引入，不用一个个引入，这里好像不能用@别名
          resources: [
            './src/common/css/base.scss',
            './src/common/css/common.scss',
            './src/common/css/iconfont.scss',
          ],
        })
        .end()
    })
  },
}
