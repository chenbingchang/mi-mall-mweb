<template>
  <div>cart</div>
</template>

<script>
export default {
  name: 'cart',
  data() {
    return {}
  },
}
</script>
<style lang="scss"></style>
