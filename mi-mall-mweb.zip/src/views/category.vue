<template>
  <div>category</div>
</template>

<script>
export default {
  name: 'category',
  data() {
    return {}
  },
}
</script>
<style lang="scss"></style>
