<template>
  <div class="index">
    <keep-alive>
      <router-view></router-view>
    </keep-alive>
    <footer class="footer">
      <a class="footer-tab" href="/">
        <i class="iconfont icon-home"></i>
        <span class="txt">首页</span>
      </a>
      <a class="footer-tab" href="/category">
        <i class="iconfont icon-category"></i>
        <span class="txt">分类</span>
      </a>
      <a class="footer-tab" href="/discover">
        <i class="iconfont icon-discovery"></i>
        <span class="txt">星球</span>
      </a>
      <a class="footer-tab" href="/cart">
        <i class="iconfont icon-cart"></i>
        <span class="txt">购物车</span>
      </a>
      <a class="footer-tab" href="/user">
        <i class="iconfont icon-user"></i>
        <span class="txt">我的</span>
      </a>
    </footer>
  </div>
</template>

<script>
// @ is an alias to /src

export default {
  name: 'index',
  data() {
    return {}
  },
  methods: {},
}
</script>

<style lang="scss">
.index {
  width: 100vw;
  height: 100vh;

  .footer {
    position: fixed;
    left: 0;
    right: 0;
    bottom: 0;
    display: flex;
    justify-content: space-around;
    align-items: center;
    height: px2rem(52);
    font-size: px2rem(18);
    background: orange;
  }

  .footer-tab {
    display: flex;
    flex-direction: column;
    align-items: center;

    .iconfont {
      margin-bottom: px2rem(5);
      font-size: px2rem(20);
      color: #7c7c7c;
      line-height: px2rem(20);
    }

    .txt {
      font-size: px2rem(12);
    }
  }
}
</style>
