<template>
  <div>user</div>
</template>

<script>
export default {
  name: 'user',
  data() {
    return {}
  },
}
</script>
<style lang="scss"></style>
