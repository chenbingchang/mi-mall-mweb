<template>
  <div>discover</div>
</template>

<script>
export default {
  name: 'discover',
  data() {
    return {}
  },
}
</script>
<style lang="scss"></style>
